# Logo da KSS

## Como adicionar a logo

1. Coloque o arquivo da logo com o nome `logo.png` neste diretório
2. Formatos aceitos: PNG, JPG, SVG
3. A logo será exibida automaticamente em todos os lugares onde aparece "KSS"

## Localização do arquivo

O arquivo deve estar em: `Public/assets/images/kss/logo.png`

## Fallback

Se a logo não existir, será exibido o texto estilizado "KSS ASSISTÊNCIA 360°" como fallback.

